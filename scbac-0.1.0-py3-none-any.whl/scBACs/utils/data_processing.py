import scanpy as sc
import numpy as np
import pandas as pd

def preprocess_data(adata, count_layer='counts', normalize=True, scale=True):
    """
    Preprocess single-cell data for age prediction
    
    Parameters:
    -----------
    adata : AnnData
        Input data
    count_layer : str
        Layer containing raw counts
    normalize : bool
        Whether to normalize data
    scale : bool
        Whether to scale data
    
    Returns:
    --------
    adata : Preprocessed AnnData
    """
    adata = adata.copy()
    
    # 使用指定的counts层
    if count_layer in adata.layers:
        adata.X = adata.layers[count_layer]
    
    # 预处理步骤
    if normalize:
        sc.pp.normalize_per_cell(adata)
        sc.pp.log1p(adata)
    
    if scale:
        sc.pp.scale(adata)
    
    return adata