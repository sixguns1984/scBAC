#!/usr/bin/env python3
"""
Script to download and install pre-trained models for scbacs from OneDrive
"""

import os
import sys
import requests
import argparse
from pathlib import Path
import time
import hashlib

def get_package_path():
    """Get the package installation path"""
    try:
        import scBACs
        return os.path.dirname(scBACs.__file__)
    except ImportError:
        print("Error: scbacs package not found. Please install it first.")
        sys.exit(1)

def get_onedrive_direct_link(shareable_link):
    """
    Convert OneDrive shareable link to direct download link
    """
    if '1drv.ms' in shareable_link or 'onedrive.live.com' in shareable_link:
        # 方法1: 使用官方API转换
        try:
            # 将分享链接转换为直接下载链接
            if '1drv.ms' in shareable_link:
                # 短链接格式，需要先获取真实链接
                session = requests.Session()
                response = session.get(shareable_link, allow_redirects=True)
                shareable_link = response.url
            
            # 从分享链接提取文件ID
            if '/redir?' in shareable_link:
                # 旧版链接格式
                file_id = shareable_link.split('id=')[1].split('&')[0]
            else:
                # 新版链接格式
                file_id = shareable_link.split('/')[5]  # 通常在第6个位置
            
            # 构造直接下载链接
            direct_url = f"https://api.onedrive.com/v1.0/shares/{file_id}/root/content"
            return direct_url
            
        except Exception as e:
            print(f"Warning: Could not convert OneDrive link automatically: {e}")
            # 如果自动转换失败，返回原始链接
            return shareable_link
    
    # 如果已经是直接下载链接，直接返回
    return shareable_link

def download_onedrive_file(direct_url, destination, max_retries=3):
    """
    Download file from OneDrive
    """
    session = requests.Session()
    
    for attempt in range(max_retries):
        try:
            print(f"Downloading {os.path.basename(destination)} (attempt {attempt + 1}/{max_retries})...")
            
            # 下载文件
            response = session.get(direct_url, stream=True, timeout=60)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            block_size = 8192
            downloaded = 0
            
            with open(destination, 'wb') as f:
                for data in response.iter_content(block_size):
                    if data:
                        downloaded += len(data)
                        f.write(data)
                        if total_size > 0:
                            percent = (downloaded / total_size) * 100
                            print(f"\rProgress: {percent:.1f}% ({downloaded}/{total_size} bytes)", end='', flush=True)
            
            print("\nDownload completed!")
            
            # 验证文件大小
            if total_size > 0 and os.path.getsize(destination) != total_size:
                raise Exception("Downloaded file size doesn't match expected size")
                
            return True
            
        except Exception as e:
            print(f"\nDownload failed: {e}")
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                print(f"Retrying in {wait_time} seconds...")
                time.sleep(wait_time)
            else:
                print("All download attempts failed.")
                return False
    
    return False

def download_with_progress(url, destination):
    """
    使用进度条下载文件
    """
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        with open(destination, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = (downloaded / total_size) * 100
                        print(f"\rProgress: {percent:.1f}% ({downloaded}/{total_size} bytes)", end='', flush=True)
        
        print("\nDownload completed!")
        return True
        
    except Exception as e:
        print(f"\nDownload error: {e}")
        return False

def download_model_collection(model_collection, models_dir, force_download=False):
    """
    Download a collection of .pth model files from OneDrive
    """
    os.makedirs(models_dir, exist_ok=True)
    
    downloaded_count = 0
    skipped_count = 0
    failed_count = 0
    
    print(f"\n📦 Downloading {len(model_collection['models'])} model files from OneDrive...")
    print("=" * 60)
    
    for i, model_info in enumerate(model_collection['models'], 1):
        model_name = model_info['name']
        model_url = model_info['url']
        filename = model_info.get('filename', f"{model_name}.pth")
        destination = os.path.join(models_dir, filename)
        
        # Check if model already exists
        if os.path.exists(destination) and not force_download:
            file_size = os.path.getsize(destination) / (1024 * 1024)  # MB
            print(f"{i}. ⚡ Skipped {filename} ({file_size:.1f} MB, already exists)")
            skipped_count += 1
            continue
        
        print(f"{i}. 📥 Downloading {filename}...")
        print(f"   From: {model_url}")
        
        # 转换 OneDrive 链接
        direct_url = get_onedrive_direct_link(model_url)
        
        if download_onedrive_file(direct_url, destination):
            file_size = os.path.getsize(destination) / (1024 * 1024)  # MB
            print(f"   ✅ {filename} ({file_size:.1f} MB)")
            downloaded_count += 1
        else:
            print(f"   ❌ Failed to download {filename}")
            failed_count += 1
        
        # Small delay between downloads to avoid rate limiting
        if i < len(model_collection['models']):
            time.sleep(1)
    
    return downloaded_count, skipped_count, failed_count

def install_models(cell_type=None, force_download=False):
    """
    Install pre-trained .pth model files for scbacs from OneDrive
    """
    package_path = get_package_path()
    models_dir = os.path.join(package_path, 'models', 'cell_age_models')
    
    # ===== 替换为您的实际 OneDrive 链接 =====
    MODEL_COLLECTIONS = {
        'all': {
            'name': 'All Cell Type Models',
            'description': 'Complete set of 13 pre-trained models for all cell types',
            'models': [
                {
                    'name': 'microglia',
                    'filename': 'Mic_mlp_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/Mic_mlp_best_model.pth?download=1',
                    'description': 'Microglia cell age prediction model'
                },
                {
                    'name': 'Excitatory neurons',
                    'filename': 'Exc_transf_best_model.pth', 
                    'url': 'https://zenodo.org/records/17529044/files/Exc_transf_best_model.pth?download=1',
                    'description': 'Excitatory neuron age prediction model'
                },
                {
                    'name': 'astrocytes',
                    'filename': 'Ast_mlp_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/Ast_mlp_best_model.pth?download=1',
                    'description': 'Astrocyte cell age prediction model'
                },
                {
                    'name': 'oligodendrocytes',
                    'filename': 'Oli_transf_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/Oli_transf_best_model.pth?download=1',
                    'description': 'Oligodendrocyte cell age prediction model'
                },
                {
                    'name': 'endothelial',
                    'filename': 'End_transf_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/End_transf_best_model.pth?download=1',
                    'description': 'Endothelial cell age prediction model'
                },
                {
                    'name': 'CAM',
                    'filename': 'CAM_mlp_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/CAM_mlp_best_model.pth?download=1',
                    'description': 'CAM cell age prediction model'
                },
                {
                    'name': 'Inhibitory neurons',
                    'filename': 'Inh_transf_best_model.pth', 
                    'url': 'https://zenodo.org/records/17529044/files/Inh_transf_best_model.pth?download=1',
                    'description': 'Inhibitory neuron cell age prediction model'
                },
                {
                    'name': 'Fib',
                    'filename': 'Fib_transf_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/Fib_transf_best_model.pth?download=1',
                    'description': 'Fib cell age prediction model'
                },
                {
                    'name': 'Mural',
                    'filename': 'Mural_transf_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/Mural_transf_best_model.pth?download=1',
                    'description': 'Mural cell age prediction model'
                },
                {
                    'name': 'OPC',
                    'filename': 'OPC_transf_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/OPC_transf_best_model.pth?download=1',
                    'description': 'OPC cell age prediction model'
                },
                {
                    'name': 'Per',
                    'filename': 'Per_transf_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/Per_transf_best_model.pth?download=1',
                    'description': 'Per cell age prediction model'
                },
                {
                    'name': 'SMC',
                    'filename': 'SMC_transf_best_model.pth', 
                    'url': 'https://zenodo.org/records/17529044/files/SMC_transf_best_model.pth?download=1',
                    'description': 'SMC cell age prediction model'
                },
                {
                    'name': 'T cell',
                    'filename': 'Tcell_transf_best_model.pth',
                    'url': 'https://zenodo.org/records/17529044/files/Tcell_transf_best_model.pth?download=1',
                    'description': 'T cell age prediction model'
                },                                
            ]
        }
    }
    
    if cell_type is None:
        # Interactive model selection
        print("=" * 60)
        print("scbacs Model Installation - OneDrive")
        print("=" * 60)
        print("Available model packages:\n")
        
        collections = list(MODEL_COLLECTIONS.keys())
        for i, key in enumerate(collections, 1):
            info = MODEL_COLLECTIONS[key]
            model_count = len(info['models'])
            print(f"{i}. {info['name']}")
            print(f"   {info['description']}")
            print(f"   Contains {model_count} model file(s)")
            print()
        
        while True:
            try:
                choice = input(f"Select package (1-{len(collections)}, default 1): ").strip()
                if choice == '':
                    choice = '1'
                
                choice_idx = int(choice) - 1
                selected_key = collections[choice_idx]
                selected_collection = MODEL_COLLECTIONS[selected_key]
                
                print(f"\nSelected: {selected_collection['name']}")
                break
                
            except (ValueError, IndexError):
                print(f"Invalid selection. Please enter a number between 1 and {len(collections)}.")
    else:
        # Use specified cell type
        if cell_type not in MODEL_COLLECTIONS:
            print(f"Error: Cell type '{cell_type}' not found in available models.")
            print(f"Available types: {', '.join(MODEL_COLLECTIONS.keys())}")
            sys.exit(1)
        selected_collection = MODEL_COLLECTIONS[cell_type]
    
    # Download models
    try:
        downloaded, skipped, failed = download_model_collection(
            selected_collection, models_dir, force_download
        )
        
        # Summary
        print("\n" + "=" * 60)
        print("📊 Installation Summary:")
        print(f"   ✅ Downloaded: {downloaded} file(s)")
        print(f"   ⚡ Skipped: {skipped} file(s) (already exist)")
        print(f"   ❌ Failed: {failed} file(s)")
        print(f"   📁 Location: {models_dir}")
        
        if failed == 0:
            print(f"\n🎉 Installation completed! You can now use scbacs with {selected_collection['name']}.")
        else:
            print(f"\n⚠️  Some models failed to download. You may need to:")
            print(f"    1. Check your internet connection")
            print(f"    2. Verify the OneDrive links are accessible")
            print(f"    3. Run the installation again")
        
    except Exception as e:
        print(f"❌ Error installing models: {e}")
        sys.exit(1)

def list_installed_models():
    """List currently installed models"""
    package_path = get_package_path()
    models_dir = os.path.join(package_path, 'models', 'cell_age_models')
    
    if not os.path.exists(models_dir):
        print("No models directory found. Please install models first.")
        return
    
    existing_models = list(Path(models_dir).glob('*.pth'))
    
    if existing_models:
        print("Installed models:")
        for i, model in enumerate(existing_models, 1):
            file_size = model.stat().st_size / (1024 * 1024)  # MB
            print(f"{i}. {model.name} ({file_size:.1f} MB)")
        
        print(f"\nTotal: {len(existing_models)} model files installed.")
    else:
        print("No models installed. Run the installation script to download models.")

def validate_models():
    """Validate that all required models are installed"""
    package_path = get_package_path()
    models_dir = os.path.join(package_path, 'models', 'cell_age_models')
    
    if not os.path.exists(models_dir):
        print("❌ Models directory not found.")
        return False
    
    existing_models = list(Path(models_dir).glob('*.pth'))
    
    if not existing_models:
        print("❌ No model files found.")
        return False
    
    print(f"✅ Found {len(existing_models)} model files:")
    for model in existing_models:
        file_size = model.stat().st_size / (1024 * 1024)  # MB
        print(f"   - {model.name} ({file_size:.1f} MB)")
    
    return True

def main():
    parser = argparse.ArgumentParser(
        description='Download and install pre-trained .pth model files for scbacs from OneDrive',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                          # Interactive installation
  %(prog)s --cell-type all          # Download all 13 cell type models
  %(prog)s --cell-type immune       # Download only immune cell models
  %(prog)s --force-download         # Force reinstall existing models
  %(prog)s --list-models            # List installed models
  %(prog)s --validate               # Validate installed models

OneDrive Setup:
  1. Upload each .pth file to OneDrive
  2. Share each file with "Anyone with the link can view"
  3. Update the URLs in this script with your actual OneDrive links
        """
    )
    
    parser.add_argument('--cell-type', type=str, 
                       help='Specific cell type to download (e.g., all, immune, neural)')
    parser.add_argument('--force-download', action='store_true', 
                       help='Force download even if models exist')
    parser.add_argument('--list-models', action='store_true',
                       help='List currently installed models')
    parser.add_argument('--validate', action='store_true',
                       help='Validate installed models')
    
    args = parser.parse_args()
    
    if args.list_models:
        list_installed_models()
        return
    
    if args.validate:
        validate_models()
        return
    
    install_models(args.cell_type, args.force_download)

if __name__ == '__main__':
    main()