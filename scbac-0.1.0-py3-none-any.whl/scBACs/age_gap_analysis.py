"""
Age gap analysis and turning point detection for cell age predictions
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.interpolate import interp1d
from scipy import stats
from statsmodels.stats.multitest import multipletests
import warnings
warnings.filterwarnings('ignore')
import matplotlib
from functools import reduce

# Set Nature style for plots
plt.rcParams.update({
    'font.size': 9,
    'axes.labelsize': 10,
    'axes.titlesize': 11,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'figure.titlesize': 12,
    'font.family': 'Arial',
    'mathtext.fontset': 'stix',
    'axes.linewidth': 0.8,
    'lines.linewidth': 1.5,
    'patch.linewidth': 0.8,
    'xtick.major.width': 0.8,
    'ytick.major.width': 0.8,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.1
})

# Nature color palette
NATURE_COLORS = {
    'disease': '#E64B35',
    'control': '#7F7F7F',
    'significant': '#2E8B57',
    'non_significant': '#D3D3D3'
}


def calculate_donor_celltype_age_gap(df, disease_name, status_col='status',donor_id_col='PaticipantID_unique', 
                                   celltype_col='celltype', cell_age_pred_col='cell_age_pred',
                                   chronological_age_col='Real age', sex_col='Sex'):
    """
    Calculate age gap using residuals from linear model fitted separately for each cell type:
    cell_age_pred ~ Real age + Sex + donor_cell_count
    
    Parameters:
    - df: DataFrame containing single-cell data
    - donor_id_col: Column name for donor ID
    - celltype_col: Column name for cell type
    - cell_age_pred_col: Column name for predicted age
    - chronological_age_col: Column name for age at death
    - sex_col: Column name for sex
    
    Returns:
    - DataFrame with added 'age_gap' column (residuals from celltype-specific linear models)
    """
    print("Calculating age gap using celltype-specific linear model residuals...")
    
    df = df.loc[df[status_col]==disease_name].copy()
    
    # First, calculate donor_cell_count for each donor
    print("Calculating donor cell counts...")
    donor_cell_counts = df.groupby(donor_id_col).size().reset_index(name='donor_cell_count')
    df = df.merge(donor_cell_counts, on=donor_id_col, how='left')
    
    # Check if required columns exist
    required_cols = [cell_age_pred_col, chronological_age_col, sex_col, 'donor_cell_count']
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")
    
    # Check data types and handle categorical variables
    if df[sex_col].dtype == 'object':
        # Convert sex to categorical codes if it's string
        df['sex_encoded'] = df[sex_col].astype('category').cat.codes
        sex_var = 'sex_encoded'
    else:
        sex_var = sex_col
    
    # Initialize age_gap column
    df['age_gap'] = np.nan
    
    # Get unique cell types
    cell_types = df[celltype_col].unique()
    print(f"Fitting linear models for {len(cell_types)} cell types...")
    
    try:
        import statsmodels.api as sm
        
        model_results = {}
        
        for i, celltype in enumerate(cell_types):
            celltype_mask = df[celltype_col] == celltype
            celltype_data = df[celltype_mask]
            
            print(f"  [{i+1}/{len(cell_types)}] Processing {celltype}: {len(celltype_data)} cells")
            
            if len(celltype_data) < 10:  # Need enough data points to fit model
                print(f"    Warning: Not enough data points for {celltype}, using simple mean centering")
                df.loc[celltype_mask, 'age_gap'] = (
                    celltype_data[cell_age_pred_col] - celltype_data[cell_age_pred_col].mean()
                )
                model_results[celltype] = {'method': 'mean_centering', 'n_obs': len(celltype_data)}
                continue
            
            # Prepare the independent variables for this cell type
            X = celltype_data[[chronological_age_col, sex_var, 'donor_cell_count']].copy()
            X = sm.add_constant(X)
            y = celltype_data[cell_age_pred_col]
            
            try:
                # Fit linear regression model for this cell type
                model = sm.OLS(y, X).fit()
                
                # Calculate residuals as age gap
                df.loc[celltype_mask, 'age_gap'] = model.resid
                
                model_results[celltype] = {
                    'method': 'linear_model',
                    'n_obs': len(celltype_data),
                    'r_squared': model.rsquared,
                    'r_squared_adj': model.rsquared_adj
                }
                
                print(f"    R-squared: {model.rsquared:.4f}, Adj R-squared: {model.rsquared_adj:.4f}")
                
            except Exception as e:
                print(f"    Warning: Model fitting failed for {celltype}, using mean centering. Error: {e}")
                df.loc[celltype_mask, 'age_gap'] = (
                    celltype_data[cell_age_pred_col] - celltype_data[cell_age_pred_col].mean()
                )
                model_results[celltype] = {'method': 'mean_centering_fallback', 'n_obs': len(celltype_data)}
        
    except ImportError:
        print("statsmodels not available, using scikit-learn instead...")
        from sklearn.linear_model import LinearRegression
        
        for i, celltype in enumerate(cell_types):
            celltype_mask = df[celltype_col] == celltype
            celltype_data = df[celltype_mask]
            
            print(f"  [{i+1}/{len(cell_types)}] Processing {celltype}: {len(celltype_data)} cells")
            
            if len(celltype_data) < 10:
                print(f"    Warning: Not enough data points for {celltype}, using simple mean centering")
                df.loc[celltype_mask, 'age_gap'] = (
                    celltype_data[cell_age_pred_col] - celltype_data[cell_age_pred_col].mean()
                )
                continue
            
            # Prepare the independent variables for this cell type
            X = celltype_data[[chronological_age_col, sex_var, 'donor_cell_count']].copy()
            y = celltype_data[cell_age_pred_col]
            
            try:
                # Fit linear regression model for this cell type
                model = LinearRegression()
                model.fit(X, y)
                
                # Calculate residuals as age gap
                y_pred = model.predict(X)
                df.loc[celltype_mask, 'age_gap'] = y - y_pred
                
                r_squared = model.score(X, y)
                print(f"    R-squared: {r_squared:.4f}")
                
            except Exception as e:
                print(f"    Warning: Model fitting failed for {celltype}, using mean centering. Error: {e}")
                df.loc[celltype_mask, 'age_gap'] = (
                    celltype_data[cell_age_pred_col] - celltype_data[cell_age_pred_col].mean()
                )
    
    # Print summary statistics
    print(f"\n=== Model Fitting Summary ===")
    if 'model_results' in locals():
        for celltype, results in model_results.items():
            method = results['method']
            n_obs = results['n_obs']
            if method == 'linear_model':
                r2 = results['r_squared']
                r2_adj = results['r_squared_adj']
                print(f"{celltype}: {n_obs} obs, R²={r2:.4f}, Adj R²={r2_adj:.4f}")
            else:
                print(f"{celltype}: {n_obs} obs, {method}")
    
    # Check for any missing values and fill with mean centering if necessary
    missing_age_gap = df['age_gap'].isna().sum()
    if missing_age_gap > 0:
        print(f"Warning: {missing_age_gap} age_gap values are missing, filling with mean centering...")
        missing_mask = df['age_gap'].isna()
        df.loc[missing_mask, 'age_gap'] = (
            df.loc[missing_mask, cell_age_pred_col] - 
            df.loc[missing_mask].groupby([donor_id_col, celltype_col])[cell_age_pred_col].transform('mean')
        )
    
    # Print statistics about the calculated age gap
    print(f"\n=== Age Gap Statistics ===")
    print(f"Range: {df['age_gap'].min():.2f} to {df['age_gap'].max():.2f}")
    print(f"Mean: {df['age_gap'].mean():.4f}")
    print(f"Std: {df['age_gap'].std():.4f}")
    
    # Print statistics by cell type
    print(f"\n=== Age Gap Statistics by Cell Type ===")
    age_gap_stats = df.groupby(celltype_col)['age_gap'].agg(['mean', 'std', 'count']).round(4)
    print(age_gap_stats)
    
    # Check correlation between cell_age_pred and age_gap by cell type
    print(f"\n=== Correlation between cell_age_pred and age_gap by Cell Type ===")
    correlations = df.groupby(celltype_col).apply(
        lambda x: x[cell_age_pred_col].corr(x['age_gap'])
    ).round(4)
    print(correlations)
    
    # Remove temporary columns
    if 'sex_encoded' in df.columns:
        df = df.drop('sex_encoded', axis=1)
    
    return df


def fast_fit_donor_smooth_curve_batch(donor_cell_data, cell_age_pred_col='cell_age_pred', age_gap_col='age_gap', n_points=100):
    """
    Fast batch processing of smooth curve fitting with vectorized operations
    """
    if len(donor_cell_data) < 8:
        return None, None
    
    try:
        # Vectorized sorting and filtering
        sorted_data = donor_cell_data.sort_values(cell_age_pred_col)
        cell_age_pred = sorted_data[cell_age_pred_col].values
        age_gap = sorted_data[age_gap_col].values
        
        # Fast outlier removal using vectorized operations
        Q1 = np.percentile(age_gap, 25)
        Q3 = np.percentile(age_gap, 75)
        IQR = Q3 - Q1
        mask = (age_gap >= Q1 - 1.5*IQR) & (age_gap <= Q3 + 1.5*IQR)
        
        cell_age_pred_clean = cell_age_pred[mask]
        age_gap_clean = age_gap[mask]
        
        if len(cell_age_pred_clean) < 6:
            return None, None
        
        # Create smooth grid - reduced points for speed
        cell_age_pred_smooth = np.linspace(cell_age_pred_clean.min(), cell_age_pred_clean.max(), n_points)
        
        # Vectorized sliding window with broadcasting
        window_half = 2.0  # Fixed window size for speed
        age_gap_smooth = np.full(n_points, np.nan)
        
        # Precompute distances for all points at once
        distances = np.abs(cell_age_pred_smooth[:, np.newaxis] - cell_age_pred_clean)
        window_masks = distances <= window_half
        
        for i in range(n_points):
            window_indices = window_masks[i]
            if np.sum(window_indices) > 0:
                age_gap_smooth[i] = np.mean(age_gap_clean[window_indices])
        
        # Fast interpolation with fewer checks
        valid_mask = ~np.isnan(age_gap_smooth)
        if np.sum(valid_mask) >= 4:  # Reduced requirement
            f = interp1d(cell_age_pred_smooth[valid_mask], age_gap_smooth[valid_mask], 
                         kind='linear', bounds_error=False, fill_value=np.nan)
            age_gap_smooth_filled = f(cell_age_pred_smooth)
            
            # Replace any remaining NaNs with nearest valid value
            nan_mask = np.isnan(age_gap_smooth_filled)
            if np.any(nan_mask) and np.any(~nan_mask):
                # Fast forward fill and backward fill
                valid_indices = np.where(~nan_mask)[0]
                if len(valid_indices) > 0:
                    first_valid = valid_indices[0]
                    last_valid = valid_indices[-1]
                    age_gap_smooth_filled[:first_valid] = age_gap_smooth_filled[first_valid]
                    age_gap_smooth_filled[last_valid:] = age_gap_smooth_filled[last_valid]
            
            return cell_age_pred_smooth, age_gap_smooth_filled
        
    except Exception:
        pass
    
    return None, None


def fast_find_threshold_from_curve(cell_age_pred_smooth, age_gap_smooth):
    """
    Fast threshold finding with vectorized operations
    """
    # Vectorized search for first positive value
    positive_mask = age_gap_smooth > 0
    positive_indices = np.where(positive_mask)[0]
    
    if len(positive_indices) > 0:
        return cell_age_pred_smooth[positive_indices[0]]
    return None


def fast_calculate_donor_curve_thresholds(df, disease_name, status_col='status', 
                                        donor_id_col='PaticipantID_unique',
                                        celltype_col='celltype', 
                                        cell_age_pred_col='cell_age_pred',
                                        age_gap_col='age_gap',
                                        min_cells=10,
                                        n_points=100):
    """
    Calculate individual donor curve thresholds for age gap turning points
    """
    print(f"Fast calculation of individual donor curve thresholds for {disease_name} group...")
    
    # Pre-filter disease group
    disease_mask = df[status_col] == disease_name
    disease_df = df[disease_mask].copy()
    
    # Pre-group data for efficient iteration
    grouped = disease_df.groupby([donor_id_col, celltype_col])
    
    threshold_results = []
    curve_data = {}  # Add curve_data storage
    processed = 0
    skipped_low_cells = 0
    
    # Process groups in batch
    for (donor, cell_type), group in grouped:
        if len(group) < min_cells:
            skipped_low_cells += 1
            continue
            
        # Fast curve fitting
        cell_age_pred_smooth, age_gap_smooth = fast_fit_donor_smooth_curve_batch(
            group, cell_age_pred_col, age_gap_col, n_points
        )
        
        if cell_age_pred_smooth is not None:
            # Fast threshold finding
            threshold_age = fast_find_threshold_from_curve(cell_age_pred_smooth, age_gap_smooth)
            
            if threshold_age is not None:
                threshold_results.append({
                    'donor_id': donor,
                    'celltype': cell_type,
                    'threshold_age': threshold_age,
                    'n_cells': len(group)
                })
                
                # Store curve data
                curve_key = f"{donor}_{cell_type}"
                curve_data[curve_key] = {
                    'cell_age_pred': cell_age_pred_smooth,
                    'age_gap': age_gap_smooth,
                    'threshold': threshold_age
                }
                processed += 1
    
    threshold_df = pd.DataFrame(threshold_results)
    
    print(f"Successfully processed {processed} donor-celltype combinations")
    print(f"Skipped {skipped_low_cells} due to insufficient cells")
    print(f"Covering {threshold_df['donor_id'].nunique()} donors and {threshold_df['celltype'].nunique()} cell types")
    
    return threshold_df, curve_data  # Return curve_data


def analyze_threshold_differences(threshold_df):
    """
    Analyze differences in age_gap > 0 thresholds between cell types
    """
    print("Analyzing threshold differences between cell types...")
    
    # Filter cell types with sufficient data
    celltype_counts = threshold_df['celltype'].value_counts()
    valid_celltypes = celltype_counts[celltype_counts >= 3].index.tolist()  # At least 3 donors
    
    if len(valid_celltypes) < 2:
        print("Not enough cell types with sufficient data for comparison")
        return None
    
    filtered_df = threshold_df[threshold_df['celltype'].isin(valid_celltypes)]
    
    # Calculate mean threshold for each cell type
    celltype_stats = filtered_df.groupby('celltype').agg({
        'threshold_age': ['mean', 'std', 'count', 'min', 'max'],
        'n_cells': 'mean'
    }).round(3)
    
    celltype_stats.columns = [
        'mean_threshold', 'std_threshold', 'n_donors', 'min_threshold', 'max_threshold',
        'mean_cells_per_donor'
    ]
    celltype_stats = celltype_stats.sort_values('mean_threshold')
    
    # Perform ANOVA to test overall differences
    anova_result = stats.f_oneway(*[group['threshold_age'].values 
                                   for name, group in filtered_df.groupby('celltype')])
    
    print(f"ANOVA result: F={anova_result.statistic:.3f}, p={anova_result.pvalue:.4f}")
    
    # Perform pairwise t-tests with multiple testing correction
    celltype_pairs = []
    p_values = []
    
    celltypes = celltype_stats.index.tolist()
    
    for i in range(len(celltypes)):
        for j in range(i + 1, len(celltypes)):
            celltype1 = celltypes[i]
            celltype2 = celltypes[j]
            
            data1 = filtered_df[filtered_df['celltype'] == celltype1]['threshold_age']
            data2 = filtered_df[filtered_df['celltype'] == celltype2]['threshold_age']
            
            if len(data1) >= 2 and len(data2) >= 2:
                t_stat, p_val = stats.mannwhitneyu(data1, data2)
                celltype_pairs.append(f"{celltype1}_vs_{celltype2}")
                p_values.append(p_val)
    
    # Apply multiple testing correction
    if p_values:
        rejected, corrected_pvals, _, _ = multipletests(p_values, alpha=0.05, method='fdr_bh')
        
        pairwise_results = pd.DataFrame({
            'comparison': celltype_pairs,
            'p_value': p_values,
            'adjusted_p_value': corrected_pvals,
            'significant': rejected
        })
        
        # Add mean difference information
        pairwise_results['celltype1'] = [pair.split('_vs_')[0] for pair in celltype_pairs]
        pairwise_results['celltype2'] = [pair.split('_vs_')[1] for pair in celltype_pairs]
        
        for idx, row in pairwise_results.iterrows():
            mean1 = celltype_stats.loc[row['celltype1'], 'mean_threshold']
            mean2 = celltype_stats.loc[row['celltype2'], 'mean_threshold']
            pairwise_results.loc[idx, 'mean_difference'] = mean1 - mean2
        
        pairwise_results = pairwise_results.sort_values('adjusted_p_value')
    else:
        pairwise_results = pd.DataFrame()
    
    analysis_results = {
        'celltype_stats': celltype_stats,
        'anova_pvalue': anova_result.pvalue,
        'pairwise_comparisons': pairwise_results,
        'filtered_data': filtered_df
    }
    
    return analysis_results


def visualize_donor_curves_examples(curve_data, threshold_df, disease_name, 
                                  celltypes_to_plot=None, donor_list=None, n_examples=3,
                                  save_path=None):
    """
    Visualize example donor curves with thresholds, with multiple cell types in same subplot
    """
    
    # Determine cell types to plot
    if celltypes_to_plot is None:
        # Use top 3 cell types with most donors
        celltypes_to_plot = threshold_df['celltype'].value_counts().head(3).index.tolist()
    else:
        # Filter to only include cell types that exist in data
        available_celltypes = threshold_df['celltype'].unique()
        celltypes_to_plot = [ct for ct in celltypes_to_plot if ct in available_celltypes]
    
    print(f"Plotting cell types: {celltypes_to_plot}")
    
    # Determine donors to plot
    if donor_list is None:
        # Find donors that have data for all specified cell types
        donor_celltype_counts = threshold_df[threshold_df['celltype'].isin(celltypes_to_plot)]\
            .groupby('donor_id')['celltype'].nunique()
        
        # Select donors that have at least 2 of the specified cell types
        eligible_donors = donor_celltype_counts[donor_celltype_counts >= 2].index.tolist()
        
        if len(eligible_donors) == 0:
            print("No donors have multiple cell types from the specified list. Using donors with any cell type.")
            eligible_donors = threshold_df[threshold_df['celltype'].isin(celltypes_to_plot)]['donor_id'].unique()
        
        # Randomly select donors
        if len(eligible_donors) > n_examples:
            import random
            donors_to_plot = random.sample(eligible_donors, n_examples)
        else:
            donors_to_plot = eligible_donors[:n_examples]
    else:
        donors_to_plot = donor_list[:n_examples]
    
    print(f"Plotting donors: {donors_to_plot}")
    
    # Create figure
    fig, axes = plt.subplots(1, len(donors_to_plot), figsize=(5*len(donors_to_plot), 4))
    if len(donors_to_plot) == 1:
        axes = [axes]
    
    # Define colors for different cell types
    colors = plt.cm.Set3(np.linspace(0, 1, len(celltypes_to_plot)))
    
    for j, donor in enumerate(donors_to_plot):
        ax = axes[j]
        
        # Plot all cell types for this donor in the same subplot
        for i, cell_type in enumerate(celltypes_to_plot):
            curve_key = f"{donor}_{cell_type}"
            if curve_key in curve_data:
                curve_info = curve_data[curve_key]
                
                # Plot the curve
                ax.plot(curve_info['cell_age_pred'], curve_info['age_gap'], 
                       color=colors[i], linewidth=2.5, alpha=0.8, label=cell_type)
                
                # Add threshold line
                threshold_value = curve_info.get('threshold', None)
                if threshold_value is not None:
                    ax.axvline(x=threshold_value, color=colors[i], linestyle=':', 
                              linewidth=2, alpha=0.7, 
                              label=f'{cell_type} threshold: {threshold_value:.1f}')
        
        # Add common elements
        ax.axhline(y=0, color='black', linestyle='--', alpha=0.5, linewidth=1)
        ax.set_xlabel('Predicted Age', fontsize=12)
        ax.set_ylabel('Age Gap', fontsize=12)
        ax.set_title(f'Donor: {donor}', fontsize=13, fontweight='bold')
        ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        ax.grid(True, alpha=0.3)
        
        # Set consistent x and y limits across all subplots
        all_cell_age_pred = []
        all_age_gap = []
        for cell_type in celltypes_to_plot:
            curve_key = f"{donor}_{cell_type}"
            if curve_key in curve_data:
                curve_info = curve_data[curve_key]
                all_cell_age_pred.extend(curve_info['cell_age_pred'])
                all_age_gap.extend(curve_info['age_gap'])
        
        if all_cell_age_pred and all_age_gap:
            ax.set_xlim(min(all_cell_age_pred), max(all_cell_age_pred))
            # Add some padding to y-axis
            y_min, y_max = min(all_age_gap), max(all_age_gap)
            y_padding = (y_max - y_min) * 0.1
            ax.set_ylim(y_min - y_padding, y_max + y_padding)
    
    plt.suptitle(f'{disease_name}: Donor Curves Comparison\n(Cell Types: {", ".join(celltypes_to_plot)})', 
                fontsize=16, fontweight='bold', y=0.98)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()


def visualize_threshold_analysis(threshold_df, analysis_results, disease_name, save_path=None):
    """
    Create comprehensive visualization of threshold analysis
    """
    if analysis_results is None:
        print("No analysis results to visualize")
        return
    
    celltype_stats = analysis_results['celltype_stats']
    filtered_df = analysis_results['filtered_data']
    pairwise_results = analysis_results['pairwise_comparisons']
    
    # Create four subplots
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    ax1, ax2, ax3, ax4 = axes.flat
    
    # 1. Boxplot of thresholds by cell type
    celltypes_ordered = celltype_stats.index.tolist()
    box_data = [filtered_df[filtered_df['celltype'] == ct]['threshold_age'] 
                for ct in celltypes_ordered]
    
    box_plot = ax1.boxplot(box_data, labels=celltypes_ordered, patch_artist=True)
    
    # Color boxes based on mean threshold
    for patch, ct in zip(box_plot['boxes'], celltypes_ordered):
        rank = celltypes_ordered.index(ct) / len(celltypes_ordered)
        color = plt.cm.RdBu_r(rank)
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    
    # Add significance comparisons
    earliest_celltype = celltypes_ordered[0]
    earliest_comparisons = pairwise_results[
        (pairwise_results['celltype1'] == earliest_celltype) | 
        (pairwise_results['celltype2'] == earliest_celltype)
    ]
    
    if not earliest_comparisons.empty:
        y_max = max([max(data) if len(data) > 0 else 0 for data in box_data])
        y_min = min([min(data) if len(data) > 0 else 0 for data in box_data])
        plot_height = y_max - y_min
        
        # Add significance bars
        bar_height = 0.02 * plot_height
        current_y = y_max + 0.05 * plot_height
        for _, comp_row in earliest_comparisons.iterrows():
            if comp_row['significant']:
                if comp_row['celltype1'] == earliest_celltype:
                    other_celltype = comp_row['celltype2']
                else:
                    other_celltype = comp_row['celltype1']
                
                pos1 = celltypes_ordered.index(earliest_celltype) + 1
                pos2 = celltypes_ordered.index(other_celltype) + 1
                
                ax1.plot([pos1, pos1, pos2, pos2], 
                        [current_y, current_y + bar_height, current_y + bar_height, current_y], 
                        'k-', linewidth=1.5)
                
                p_val = comp_row['adjusted_p_value']
                if p_val < 0.001:
                    stars = '***'
                elif p_val < 0.01:
                    stars = '**'
                elif p_val < 0.05:
                    stars = '*'
                else:
                    stars = 'ns'
                
                mid_x = (pos1 + pos2) / 2
                ax1.text(mid_x, current_y + bar_height + 0.01 * plot_height, stars,
                        ha='center', va='bottom', fontweight='bold', fontsize=10)
                
                current_y += 0.08 * plot_height
        
        ax1.set_ylim(y_min, current_y + 0.1 * plot_height)
    
    ax1.set_ylabel('Age Pred Threshold (age_gap > 0)')
    ax1.set_title(f'{disease_name}: Individual Donor Thresholds by Cell Type', 
                  fontweight='bold')
    ax1.tick_params(axis='x', rotation=45)
    ax1.grid(True, alpha=0.3, axis='y')
    
    # 2. Mean thresholds with confidence intervals
    y_pos = range(len(celltype_stats))
    means = celltype_stats['mean_threshold']
    stds = celltype_stats['std_threshold']
    
    colors = [plt.cm.RdBu_r(i/len(celltype_stats)) for i in range(len(celltype_stats))]
    bars = ax2.barh(y_pos, means, xerr=stds, color=colors, alpha=0.7, capsize=5)
    
    ax2.set_yticks(y_pos)
    ax2.set_yticklabels(celltype_stats.index)
    ax2.set_xlabel('Mean Threshold Age')
    ax2.set_title('Cell Type Aging Sequence', fontweight='bold')
    ax2.grid(True, alpha=0.3, axis='x')
    
    # Add value labels
    for i, (mean, std) in enumerate(zip(means, stds)):
        ax2.text(mean + std + 0.5, i, f'{mean:.1f}±{std:.1f}', 
                va='center', fontsize=8, fontweight='bold')
    
    # 3. Heatmap of donor thresholds
    pivot_data = filtered_df.pivot_table(
        index='donor_id', 
        columns='celltype', 
        values='threshold_age'
    )
    
    # Reorder columns by mean threshold
    celltypes_ordered_by_mean = pivot_data.mean().sort_values().index.tolist()
    pivot_data = pivot_data[celltypes_ordered_by_mean]
    
    # Create heatmap
    im = ax3.imshow(pivot_data.values, cmap='RdBu_r', aspect='auto')
    
    ax3.set_xticks(range(len(celltypes_ordered_by_mean)))
    ax3.set_xticklabels(celltypes_ordered_by_mean, rotation=45, ha='right')
    ax3.set_yticks(range(len(pivot_data.index)))
    ax3.set_yticklabels(pivot_data.index)
    ax3.set_xlabel('Cell Type')
    ax3.set_ylabel('Donor ID')
    ax3.set_title('Donor-Level Aging Patterns\n(Blue=Early, Red=Late)', 
                  fontweight='bold')
    
    # Add colorbar
    cbar = plt.colorbar(im, ax=ax3, shrink=0.8)
    cbar.set_label('Threshold Age', rotation=270, labelpad=15)
    
    # 4. Statistical significance
    if not pairwise_results.empty:
        top_comparisons = pairwise_results[pairwise_results['significant']].head(8)
        if len(top_comparisons) > 0:
            y_pos = range(len(top_comparisons))
            comparisons = [f"{row['celltype1']}\nvs\n{row['celltype2']}" 
                          for _, row in top_comparisons.iterrows()]
            p_values = -np.log10(top_comparisons['adjusted_p_value'])
            
            bars = ax4.barh(y_pos, p_values, color='red', alpha=0.7)
            ax4.set_yticks(y_pos)
            ax4.set_yticklabels(comparisons, fontsize=8)
            ax4.set_xlabel('-log10(Adjusted P-value)')
            ax4.set_title('Significant Aging Sequence Differences', 
                         fontweight='bold')
            ax4.grid(True, alpha=0.3, axis='x')
            
            for i, (bar, row) in enumerate(zip(bars, top_comparisons.iterrows())):
                ax4.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height()/2,
                        f'Δ={row[1]["mean_difference"]:.1f}', va='center', 
                        fontsize=7, fontweight='bold')
        else:
            ax4.text(0.5, 0.5, 'No significant differences', 
                    ha='center', va='center', transform=ax4.transAxes)
            ax4.set_title('Pairwise Comparisons', fontweight='bold')
    else:
        ax4.text(0.5, 0.5, 'No comparisons available', 
                ha='center', va='center', transform=ax4.transAxes)
        ax4.set_title('Pairwise Comparisons', fontweight='bold')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()


def analyze_age_gap_ratio(df, donor_id_col='PaticipantID_unique', celltype_col='celltype', age_gap_col='age_gap'):
    """
    Analyze the ratio of cells with positive age gap for each participant and cell type
    """
    # Calculate ratio
    result = df.groupby([donor_id_col, celltype_col]).agg({
        age_gap_col: [
            ('total_cells', 'count'),
            ('positive_count', lambda x: (x > 0).sum()),
            ('positive_ratio', lambda x: (x > 0).mean()),
            ('mean_age_gap', 'mean'),
            ('std_age_gap', 'std')
        ]
    }).round(4)
    
    # Flatten column names
    result.columns = ['total_cells', 'positive_count', 'positive_ratio', 'mean_age_gap', 'std_age_gap']
    result = result.reset_index()
    
    return result

def save_analysis_results(results, save_prefix):
    """Save analysis results to files"""
    import os
    from pathlib import Path
    
    if not save_prefix:
        print("No save prefix provided, skipping file saving")
        return
    
    # Create output directory if it doesn't exist
    output_dir = os.path.dirname(save_prefix)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
        print(f"Created output directory: {output_dir}")
    
    print(f"\nSaving results with prefix: {save_prefix}")
    
    try:
        # Extract results
        df_with_gap = results['df_with_gap']
        threshold_df = results['threshold_df']
        ratio_results = results['ratio_results']
        analysis_results = results['analysis_results']
        
        # Save DataFrames
        print(f"  1. Saving data with age gap...")
        df_with_gap.to_csv(f"{save_prefix}_with_age_gap.csv")
        
        print(f"  2. Saving thresholds...")
        threshold_df.to_csv(f"{save_prefix}_thresholds.csv")
        
        print(f"  3. Saving positive ratio results...")
        ratio_results.to_csv(f"{save_prefix}_positive_ratio.csv")
        
        if analysis_results is not None:
            print(f"  4. Saving cell type statistics...")
            analysis_results['celltype_stats'].to_csv(f"{save_prefix}_celltype_stats.csv")
            
            if not analysis_results['pairwise_comparisons'].empty:
                print(f"  5. Saving pairwise comparisons...")
                analysis_results['pairwise_comparisons'].to_csv(f"{save_prefix}_pairwise_comparisons.csv")
        
        print(f"✓ All results saved successfully!")
        
    except Exception as e:
        print(f"✗ Error saving results: {e}")

        
def age_gap_turning_point_analysis(df, disease_name='AD', status_col='status',
                                   donor_id_col='PaticipantID_unique',
                                   celltype_col='celltype',
                                   cell_age_pred_col='cell_age_pred',
                                   chronological_age_col='Real age',
                                   sex_col='Sex',
                                   min_cells=10,
                                   save_prefix=None):
    """
    Main function for age gap turning point analysis
    
    Parameters:
    - df: DataFrame with predicted cell ages
    - disease_name: Name of the disease group to analyze
    - status_col: Column name containing disease/control status
    - donor_id_col: Column name for donor ID
    - celltype_col: Column name for cell type
    - cell_age_pred_col: Column name for predicted age
    - chronological_age_col: Column name for age at death
    - sex_col: Column name for sex
    - min_cells: Minimum cells required per donor-celltype combination
    - save_prefix: Prefix for saving output files (if None, no files saved)
    
    Returns:
    - Dictionary containing analysis results
    """
    print(f"=== Age Gap Turning Point Analysis for {disease_name} ===")
    print("="*60)
    
    # 1. Calculate age gap
    print("Step 1: Calculating age gap...")
    df_with_gap = calculate_donor_celltype_age_gap(
        df, disease_name, status_col,donor_id_col, celltype_col, cell_age_pred_col, chronological_age_col, sex_col
    )
    
    # 2. Filter for disease group
    print(f"\nStep 2: Filtering for {disease_name} group...")
    disease_df = df_with_gap[df_with_gap[status_col] == disease_name].copy()
    
    # 3. Calculate curve thresholds
    print("\nStep 3: Calculating donor curve thresholds...")
    threshold_df, curve_data = fast_calculate_donor_curve_thresholds(
        disease_df, disease_name, status_col,
        donor_id_col, celltype_col, cell_age_pred_col, 'age_gap',
        min_cells=min_cells
    )
    
    if threshold_df.empty:
        print("No threshold data available for analysis")
        return None
    
    # 4. Analyze threshold differences
    print("\nStep 4: Analyzing threshold differences...")
    analysis_results = analyze_threshold_differences(threshold_df)
    
    # 5. Create visualizations
    if analysis_results is not None:
        print("\nStep 5: Creating visualizations...")
        
        # Main analysis plot
        if save_prefix:
            save_path = f"{save_prefix}_threshold_analysis.pdf"
        else:
            save_path = None
        
        visualize_threshold_analysis(threshold_df, analysis_results, disease_name, save_path)
        
        # Example donor curves
        if save_prefix:
            curve_save_path = f"{save_prefix}_donor_curves.pdf"
        else:
            curve_save_path = None
        
        visualize_donor_curves_examples(
            curve_data, threshold_df, disease_name,
            celltypes_to_plot=None, donor_list=None, n_examples=3,
            save_path=curve_save_path
        )
    
    # 6. Calculate positive age gap ratio
    print("\nStep 6: Calculating positive age gap ratio...")
    ratio_results = analyze_age_gap_ratio(
        disease_df, donor_id_col, celltype_col, 'age_gap'
    )
    
    # Prepare results
    results = {
        'df_with_gap': df_with_gap,
        'disease_df': disease_df,
        'threshold_df': threshold_df,
        'curve_data': curve_data,
        'analysis_results': analysis_results,
        'ratio_results': ratio_results
    }
    
    # Save results if requested
    if save_prefix:
        save_analysis_results(results, save_prefix)
    
    print("\n=== Analysis Complete ===")
    
    return results