import torch.nn as nn
import torch.nn.functional as F
import torch

class CellAgePredictor_mlp(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, dropout_prob=0.3):
        super(CellAgePredictor_mlp, self).__init__()
        self.bn_input = nn.BatchNorm1d(input_size)
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.bn1 = nn.BatchNorm1d(hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size//2)
        self.bn2 = nn.BatchNorm1d(hidden_size//2)
        self.fc3 = nn.Linear(hidden_size//2, output_size)       
        self.act = nn.LeakyReLU(0.1)
        self.dropout = nn.Dropout(dropout_prob)       
        # 初始化权重
        self._init_weights()       
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='leaky_relu')
                nn.init.constant_(m.bias, 0)               
    def forward(self, x):
        x = self.bn_input(x)
        x = self.fc1(x)
        x = self.bn1(x)
        x = self.act(x)
        x = self.dropout(x)       
        x = self.fc2(x)
        x = self.bn2(x)
        x = self.act(x)
        x = self.dropout(x)       
        return self.fc3(x)