from .mlp_model import CellAgePredictor_mlp
from .transformer_model import CellAgePredictor_transf

__all__ = ['CellAgePredictor_mlp', 'CellAgePredictor_transf']