import torch.nn as nn
import torch.nn.functional as F
import torch

class CellAgePredictor_transf(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, dropout_prob=0.5, num_heads=4, num_layers=2):
        super(CellAgePredictor_transf, self).__init__()   
        # 确保input_size能被num_heads整除
        assert input_size % num_heads == 0, "input_size must be divisible by num_heads"      
        # Transformer编码器层
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=input_size,
            nhead=num_heads,
            dim_feedforward=hidden_size,
            dropout=dropout_prob,
            activation='relu'
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)        
        # 全连接层
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, output_size)       
        # 层归一化
        self.norm1 = nn.LayerNorm(hidden_size)
        self.norm2 = nn.LayerNorm(hidden_size)
        self.norm3 = nn.LayerNorm(hidden_size)       
        # Dropout
        self.dropout = nn.Dropout(dropout_prob)       
        # 残差连接
        self.residual = nn.Linear(input_size, hidden_size)   
    def forward(self, x):
        # 输入x的形状: (batch_size, input_size)
        x = x.unsqueeze(0)  # 增加序列维度               
        # Transformer编码器
        x = self.transformer_encoder(x)
        x = x.squeeze(0)  # 去掉序列维度        
        # 残差连接 + 层归一化
        residual = self.residual(x)
        out = self.fc1(x)
        out = self.norm1(out + residual)
        out = F.relu(out)
        out = self.dropout(out)       
        # 第二层全连接
        out = self.fc2(out)
        out = self.norm2(out)
        out = F.relu(out)
        out = self.dropout(out)        
        # 输出层
        out = self.fc3(out)      
        return out