#!/usr/bin/env python3
"""
Command Line Interface for scBACs - Single Cell Brain Age Calculator
"""

import argparse
import sys
import os
import scanpy as sc
from .predictor import predict_cell_age
from .age_gap_analysis import age_gap_turning_point_analysis

def create_predict_parser(subparsers):
    """Create parser for predict subcommand"""
    parser = subparsers.add_parser('predict', help='Predict cell ages from single-cell RNA-seq data')
    
    parser.add_argument('--input', '-i', required=True,
                       help='Input AnnData file (.h5ad)')
    parser.add_argument('--output', '-o', required=True,
                       help='Output file (.h5ad or .csv)')
    parser.add_argument('--cell-type-column', '-c', default='celltypist',
                       help='Column name for cell types (default: celltypist)')
    parser.add_argument('--count-layer', '-l', default='counts',
                       help='Layer name for counts (default: counts)')
    parser.add_argument('--model-dir', '-m', 
                       help='Custom model directory')
    parser.add_argument('--device', '-d', default='cpu',
                       choices=['cpu', 'cuda'],
                       help='Device for computation (default: cpu)')
    
    return parser

def create_analyze_parser(subparsers):
    """Create parser for analyze subcommand"""
    parser = subparsers.add_parser('analyze', help='Analyze age gap turning points from cell age predictions')
    
    parser.add_argument('--input', '-i', required=True,
                       help='Input CSV file with predicted ages')
    parser.add_argument('--output-prefix', '-o', required=True,
                       help='Prefix for output files')
    parser.add_argument('--disease-name', '-d', default='AD',
                       help='Disease name to analyze (default: AD)')
    parser.add_argument('--status-col', '-s', default='status',
                       help='Column name for disease/control status (default: status)')
    parser.add_argument('--donor-col', default='PaticipantID_unique',
                       help='Column name for donor ID (default: PaticipantID_unique)')
    parser.add_argument('--celltype-col', default='celltype',
                       help='Column name for cell type (default: celltype)')
    parser.add_argument('--cell-age-pred-col', default='age_pred',
                       help='Column name for predicted age (default: age_pred)')
    parser.add_argument('--chronological-age-col', default='Age_at_death',
                       help='Column name for age at death (default: Age_at_death)')
    parser.add_argument('--sex-col', default='Sex',
                       help='Column name for sex (default: Sex)')
    parser.add_argument('--min-cells', type=int, default=10,
                       help='Minimum cells per donor-celltype combination (default: 10)')
    
    return parser

def run_predict(args):
    """Run predict command"""
    # Check input file exists
    if not os.path.exists(args.input):
        print(f"Error: Input file {args.input} does not exist")
        sys.exit(1)
    
    try:
        # Load data
        print(f"Loading data from {args.input}...")
        adata = sc.read_h5ad(args.input)
        
        # Predict cell ages
        print("Predicting cell ages...")
        results = predict_cell_age(
            adata,
            cell_type_column=args.cell_type_column,
            count_layer=args.count_layer,
            model_directory=args.model_dir,
            device=args.device
        )
        
        # Save results
        if args.output.endswith('.h5ad'):
            # Add predictions to AnnData and save
            adata.obs['predicted_age'] = results['cell_ages']
            adata.write(args.output)
            print(f"Results saved to {args.output}")
        else:
            # Save as CSV
            results['full_obs'].to_csv(args.output)
            print(f"Results saved to {args.output}")
        
        # Print summary
        print(f"\nPrediction completed!")
        print(f"Total cells processed: {len(results['cell_ages'])}")
        print(f"Age range: {results['cell_ages'].min():.3f} - {results['cell_ages'].max():.3f}")
        
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

def run_analyze(args):
    """Run analyze command"""
    import pandas as pd
    
    # Check input file exists
    if not os.path.exists(args.input):
        print(f"Error: Input file {args.input} does not exist")
        sys.exit(1)
    
    try:
        # Load data
        print(f"Loading data from {args.input}...")
        df = pd.read_csv(args.input)
        
        # Check required columns
        required_cols = [args.cell_age_pred_col, args.chronological_age_col, args.sex_col, 
                        args.status_col, args.donor_col, args.celltype_col]
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            print(f"Error: Missing required columns: {missing_cols}")
            sys.exit(1)
        
        # Run analysis
        print(f"Starting age gap turning point analysis for {args.disease_name}...")
        results = age_gap_turning_point_analysis(
            df,
            disease_name=args.disease_name,
            status_col=args.status_col,
            donor_id_col=args.donor_col,
            celltype_col=args.celltype_col,
            cell_age_pred_col=args.cell_age_pred_col,
            chronological_age_col=args.chronological_age_col,
            sex_col=args.sex_col,
            min_cells=args.min_cells,
            save_prefix=args.output_prefix
        )
        
        if results is None:
            print("Analysis failed or no data available")
            sys.exit(1)
        
        print(f"\nAnalysis completed!")
        print(f"Results saved with prefix: {args.output_prefix}")
        
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='scBACs - Single Cell Brain Age Calculator',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  scbac predict -i input.h5ad -o output.h5ad --cell-type-column celltype
  scbac analyze -i predicted_ages.csv -o analysis_results --disease-name AD
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Create subparsers
    predict_parser = create_predict_parser(subparsers)
    analyze_parser = create_analyze_parser(subparsers)
    
    # Parse arguments
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(1)
    
    # Dispatch to appropriate function
    if args.command == 'predict':
        run_predict(args)
    elif args.command == 'analyze':
        run_analyze(args)
    else:
        print(f"Unknown command: {args.command}")
        sys.exit(1)

if __name__ == '__main__':
    main()