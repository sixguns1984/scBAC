import pandas as pd
import numpy as np
import torch
import scanpy as sc
from functools import reduce
from .models.mlp_model import CellAgePredictor_mlp
from .models.transformer_model import CellAgePredictor_transf
import os

# 获取包内模型文件的路径
def get_model_path():
    """获取包内模型文件的路径"""
    return os.path.join(os.path.dirname(__file__), 'models')

def sc_age(sce, celltype, model_directory=None, device='cpu'):
    """
    Predict cell age for single cell expression data
    
    Parameters:
    -----------
    sce : torch.Tensor or array-like
        Single cell expression data (cells x genes)
    celltype : str
        Cell type for prediction
    model_directory : str, optional
        Directory containing model files. If None, uses built-in models.
    device : str
        Device for computation ('cpu' or 'cuda')
    
    Returns:
    --------
    predicted_ages : numpy.ndarray
        Predicted cell ages
    """
    if model_directory is None:
        model_directory = get_model_path()
    
    sce = torch.tensor(sce, dtype=torch.float32).to(device)
    
    # 读取模型超参数
    hyper_param_path = os.path.join(model_directory, 'model_hyper_parameter.csv')
    model_hyper_parameter = pd.read_csv(hyper_param_path)
    
    celltype_data = model_hyper_parameter[model_hyper_parameter['celltype'] == celltype]
    
    if len(celltype_data) == 0:
        raise ValueError(f"Cell type '{celltype}' not found in model database")
    
    model_type = celltype_data['model'].values[0]
    
    if model_type == 'MLP':
        input_size = sce.shape[1]
        hidden_size = int(celltype_data['hidden_size'].values[0])
        output_size = int(celltype_data['output_size'].values[0])
        dropout_prob = float(celltype_data['dropout_prob'].values[0])
        
        model = CellAgePredictor_mlp(input_size, hidden_size, output_size, dropout_prob).to(device)
        model_path = os.path.join(model_directory, 'cell_age_models', 
                                celltype_data['model_directory'].values[0])
        model.load_state_dict(torch.load(model_path, map_location=device))
        model.eval()
        
        with torch.no_grad():
            predicted_ages = model(sce).cpu().numpy().flatten()
            
    elif model_type == 'Transf':
        input_size = sce.shape[1]
        hidden_size = int(celltype_data['hidden_size'].values[0])
        output_size = int(celltype_data['output_size'].values[0])
        dropout_prob = float(celltype_data['dropout_prob'].values[0])
        num_heads = int(celltype_data['num_heads'].values[0])
        num_layers = int(celltype_data['num_layers'].values[0])
        
        model = CellAgePredictor_transf(input_size, hidden_size, output_size, 
                                      dropout_prob, num_heads, num_layers).to(device)
        model_path = os.path.join(model_directory, 'cell_age_models', 
                                celltype_data['model_directory'].values[0])
        model.load_state_dict(torch.load(model_path, map_location=device))
        model.eval()
        
        with torch.no_grad():
            predicted_ages = model(sce).cpu().numpy().flatten()
    
    else:
        raise ValueError(f"Unknown model type: {model_type}")
    
    return predicted_ages

def predict_cell_age(adata, cell_type_column='celltypist', count_layer='counts', 
                    model_directory=None, device='cpu'):
    """
    Main function for predicting cell ages from AnnData object
    
    Parameters:
    -----------
    adata : AnnData
        Annotated data matrix
    cell_type_column : str
        Column name in adata.obs containing cell type information
    count_layer : str
        Layer name containing raw counts
    model_directory : str, optional
        Directory containing model files
    device : str
        Device for computation
    
    Returns:
    --------
    dict : Dictionary containing results
    """
    if model_directory is None:
        model_directory = get_model_path()
    
    # 读取特征基因
    feature_path = os.path.join(model_directory, 'cell_age_model_features.csv')
    aginggene = pd.read_csv(feature_path)
    
    data = []
    
    for celltype in adata.obs[cell_type_column].unique():
        # 筛选特定细胞类型
        adata_sub = adata[adata.obs[cell_type_column] == celltype].copy()
        
        # 预处理
        adata_sub.X = adata_sub.layers[count_layer]
        sc.pp.normalize_per_cell(adata_sub)
        sc.pp.log1p(adata_sub)
        sc.pp.scale(adata_sub)
        
        # 获取特征基因
        model_features = aginggene.loc[aginggene['celltype'] == celltype, 'genename'].values
        common_genes = np.intersect1d(adata_sub.var.index, model_features)
        
        if len(common_genes) == 0:
            print(f"Warning: No common genes found for cell type {celltype}")
            continue
            
        adata_sub = adata_sub[:, common_genes]
        df = adata_sub.to_df()
        df = df.reindex(columns=model_features, fill_value=0)
        
        # 二值化
        X = (df.values > 0).astype(int)
        
        # 预测年龄
        predicted_ages = sc_age(X, celltype, model_directory, device)
        
        # 保存结果
        adata_sub.obs['cell_age'] = predicted_ages
        data.append(adata_sub.obs.copy())
    
    # 合并结果
    if data:
        combined_obs = reduce(lambda left, right: pd.concat([left, right], axis=0, sort=False), data)
        return {
            'cell_ages': combined_obs['cell_age'],
            'full_obs': combined_obs
        }
    else:
        raise ValueError("No predictions were made. Check cell type matching.")